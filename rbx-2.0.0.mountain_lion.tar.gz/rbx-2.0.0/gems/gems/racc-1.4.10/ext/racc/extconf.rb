# $Id: 7151daa60cd95ecbb70f5e5a8db13142d1fe2d7c $

require 'mkmf'

create_makefile 'racc/cparse'
