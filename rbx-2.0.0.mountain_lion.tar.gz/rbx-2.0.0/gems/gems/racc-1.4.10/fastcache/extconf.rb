require 'mkmf'
create_makefile 'corecache'
