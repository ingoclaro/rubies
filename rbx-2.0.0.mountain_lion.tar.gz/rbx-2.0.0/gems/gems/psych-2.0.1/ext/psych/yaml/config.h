
#define PACKAGE_NAME "yaml"
#define PACKAGE_TARNAME "yaml"
#define PACKAGE_VERSION "0.1.4"
#define PACKAGE_STRING "yaml 0.1.4"
#define PACKAGE_BUGREPORT "http://pyyaml.org/newticket?component libyaml"
#define PACKAGE_URL ""
#define YAML_VERSION_MAJOR 0
#define YAML_VERSION_MINOR 1
#define YAML_VERSION_PATCH 4
#define YAML_VERSION_STRING "0.1.4"
