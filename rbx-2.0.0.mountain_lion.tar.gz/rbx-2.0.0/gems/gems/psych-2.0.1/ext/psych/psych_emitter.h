#ifndef PSYCH_EMITTER_H
#define PSYCH_EMITTER_H

#include <psych.h>

void Init_psych_emitter();

#endif
