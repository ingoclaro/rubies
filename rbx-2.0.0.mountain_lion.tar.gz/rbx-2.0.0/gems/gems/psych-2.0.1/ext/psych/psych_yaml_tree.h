#ifndef PSYCH_YAML_TREE_H
#define PSYCH_YAML_TREE_H

#include <psych.h>

void Init_psych_yaml_tree(void);

#endif
