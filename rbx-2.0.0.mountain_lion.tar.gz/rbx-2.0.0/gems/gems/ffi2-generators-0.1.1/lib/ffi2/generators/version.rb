module FFI
  module Generators
    VERSION = "0.1.1"
  end
end
